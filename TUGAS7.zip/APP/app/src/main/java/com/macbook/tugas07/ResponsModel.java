package com.macbook.tugas07;

public class ResponsModel {
}
